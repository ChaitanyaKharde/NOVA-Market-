# NOVA Market — Full-Stack Deployment & Project Architecture Capstone

A responsive e-commerce product catalog built with React, Vite, React Router, reusable components, and local browser storage.

**Scope note:** This is a front-end portfolio demo with local product data and simulated checkout. It does not create real orders, use a production database, or process payments. Never enter real payment information.

## Features
- Modular page architecture: Home, Shop, Product detail, Cart, Wishlist, About, 404.
- React Router client-side navigation.
- Search, category filters, price filter, and sorting.
- Cart quantities, estimated shipping, and persistent cart/wishlist via localStorage.
- Responsive layouts and mobile navigation.
- Vite production build with minified JS/CSS, lazy-loaded product images, async image decoding, and preconnected image/font hosts.
- Accessible labels and reduced-motion support.
- Vercel and Netlify SPA rewrites included.

## Run locally
Install Node.js LTS, extract the ZIP, open the project folder in a terminal:
```bash
npm install
npm run dev
```
Open the local URL printed by Vite (typically `http://localhost:5173`).

## Test checklist
1. Search for “lamp” and confirm results update.
2. Filter by a category and price.
3. Sort by price and rating.
4. Open a product, change quantity, and add it to the bag.
5. Refresh and confirm cart and wishlist persist.
6. Open a product-detail URL directly and test the 404 route.
7. Test the mobile layout.
8. Run `npm run build` and confirm the `dist/` folder is generated.

## Deploy to Vercel
1. Create a GitHub repository and push this project.
2. Import that repository at [Vercel](https://vercel.com/).
3. Build command: `npm run build`; output directory: `dist`.
4. Deploy, open the public URL, and test direct routes such as `/shop` and `/product/orbit-headphones`. `vercel.json` handles SPA route rewrites.

## Deploy to Netlify
1. Push the project to GitHub.
2. Import the repository at [Netlify](https://www.netlify.com/).
3. Build command: `npm run build`; publish directory: `dist`.
4. Deploy. `netlify.toml` handles client-side route rewrites.

## Architecture
```text
nova-market-capstone/
├── index.html
├── package.json
├── vite.config.js
├── vercel.json
├── netlify.toml
└── src/
    ├── main.jsx
    ├── App.jsx
    ├── styles.css
    └── data.js
```
For a larger team project, split App.jsx into `components/` (Header, Footer, ProductCard) and `pages/` (Home, Shop, Product, Cart, Wishlist, About).

## Production readiness checklist
Before using this as a real store, replace sample product data, reviews, prices, and demo images with verified content; add a secure backend/API and database for inventory and orders; implement authentication and server-side validation if accounts are added; integrate a payment provider without storing card details yourself; add tests, privacy disclosures, custom domain, and support/legal pages; and test keyboard navigation, contrast, and performance. Images currently load from Unsplash URLs, so review image permissions and third-party terms before commercial use.

## Learning outcomes
Component-based UI, routing, state management, data-driven rendering, browser persistence, responsive CSS, asset-loading optimization, production builds, and static hosting deployment.
